import React, { createContext, useContext, useState, useCallback } from 'react';
import type {
  Client, Contact, Lead, JobOrder, Candidate, Placement, Activity
} from '../types';
import {
  CLIENTS, CONTACTS, LEADS, JOB_ORDERS, CANDIDATES, PLACEMENTS, ACTIVITIES
} from '../data/mockData';

// ── localStorage helpers ────────────────────────────────────────────────────
function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function save<T>(key: string, value: T) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* quota */ }
}

// ── Context type ────────────────────────────────────────────────────────────
interface CRMContextValue {
  clients: Client[];
  contacts: Contact[];
  leads: Lead[];
  jobOrders: JobOrder[];
  candidates: Candidate[];
  placements: Placement[];
  activities: Activity[];

  addClient: (c: Client) => void;
  updateClient: (c: Client) => void;
  deleteClient: (id: string) => void;

  addContact: (c: Contact) => void;
  updateContact: (c: Contact) => void;
  deleteContact: (id: string) => void;

  addLead: (l: Lead) => void;
  updateLead: (l: Lead) => void;
  deleteLead: (id: string) => void;

  addJobOrder: (j: JobOrder) => void;
  updateJobOrder: (j: JobOrder) => void;
  deleteJobOrder: (id: string) => void;

  addCandidate: (c: Candidate) => void;
  updateCandidate: (c: Candidate) => void;
  deleteCandidate: (id: string) => void;

  addPlacement: (p: Placement) => void;
  updatePlacement: (p: Placement) => void;

  addActivity: (a: Activity) => void;
  updateActivity: (a: Activity) => void;
  deleteActivity: (id: string) => void;
}

const CRMContext = createContext<CRMContextValue | null>(null);

// ── Helper: persisted state ─────────────────────────────────────────────────
function usePersistedState<T>(key: string, fallback: T) {
  const [value, setValue] = useState<T>(() => load<T>(key, fallback));
  const set = useCallback((updater: T | ((prev: T) => T)) => {
    setValue(prev => {
      const next = typeof updater === 'function'
        ? (updater as (prev: T) => T)(prev)
        : updater;
      save(key, next);
      return next;
    });
  }, [key]);
  return [value, set] as const;
}

// ── Provider ────────────────────────────────────────────────────────────────
export function CRMProvider({ children }: { children: React.ReactNode }) {
  const [clients,    setClients]    = usePersistedState<Client[]>   ('crm_clients',    CLIENTS);
  const [contacts,   setContacts]   = usePersistedState<Contact[]>  ('crm_contacts',   CONTACTS);
  const [leads,      setLeads]      = usePersistedState<Lead[]>     ('crm_leads',      LEADS);
  const [jobOrders,  setJobOrders]  = usePersistedState<JobOrder[]> ('crm_jobs',       JOB_ORDERS);
  const [candidates, setCandidates] = usePersistedState<Candidate[]>('crm_candidates', CANDIDATES);
  const [placements, setPlacements] = usePersistedState<Placement[]>('crm_placements', PLACEMENTS);
  const [activities, setActivities] = usePersistedState<Activity[]> ('crm_activities', ACTIVITIES);

  const addClient    = useCallback((c: Client)    => setClients(p    => [c, ...p]),              [setClients]);
  const updateClient = useCallback((c: Client)    => setClients(p    => p.map(x => x.id === c.id ? c : x)),  [setClients]);
  const deleteClient = useCallback((id: string)   => setClients(p    => p.filter(x => x.id !== id)),         [setClients]);

  const addContact    = useCallback((c: Contact)   => setContacts(p  => [c, ...p]),              [setContacts]);
  const updateContact = useCallback((c: Contact)   => setContacts(p  => p.map(x => x.id === c.id ? c : x)), [setContacts]);
  const deleteContact = useCallback((id: string)   => setContacts(p  => p.filter(x => x.id !== id)),        [setContacts]);

  const addLead    = useCallback((l: Lead)    => setLeads(p    => [l, ...p]),              [setLeads]);
  const updateLead = useCallback((l: Lead)    => setLeads(p    => p.map(x => x.id === l.id ? l : x)),  [setLeads]);
  const deleteLead = useCallback((id: string) => setLeads(p    => p.filter(x => x.id !== id)),         [setLeads]);

  const addJobOrder    = useCallback((j: JobOrder)  => setJobOrders(p => [j, ...p]),              [setJobOrders]);
  const updateJobOrder = useCallback((j: JobOrder)  => setJobOrders(p => p.map(x => x.id === j.id ? j : x)), [setJobOrders]);
  const deleteJobOrder = useCallback((id: string)   => setJobOrders(p => p.filter(x => x.id !== id)),        [setJobOrders]);

  const addCandidate    = useCallback((c: Candidate) => setCandidates(p => [c, ...p]),              [setCandidates]);
  const updateCandidate = useCallback((c: Candidate) => setCandidates(p => p.map(x => x.id === c.id ? c : x)), [setCandidates]);
  const deleteCandidate = useCallback((id: string)   => setCandidates(p => p.filter(x => x.id !== id)),        [setCandidates]);

  const addPlacement    = useCallback((p: Placement) => setPlacements(prev => [p, ...prev]),              [setPlacements]);
  const updatePlacement = useCallback((p: Placement) => setPlacements(prev => prev.map(x => x.id === p.id ? p : x)), [setPlacements]);

  const addActivity    = useCallback((a: Activity) => setActivities(p => [a, ...p]),              [setActivities]);
  const updateActivity = useCallback((a: Activity) => setActivities(p => p.map(x => x.id === a.id ? a : x)), [setActivities]);
  const deleteActivity = useCallback((id: string)  => setActivities(p => p.filter(x => x.id !== id)),        [setActivities]);

  return (
    <CRMContext.Provider value={{
      clients, contacts, leads, jobOrders, candidates, placements, activities,
      addClient, updateClient, deleteClient,
      addContact, updateContact, deleteContact,
      addLead, updateLead, deleteLead,
      addJobOrder, updateJobOrder, deleteJobOrder,
      addCandidate, updateCandidate, deleteCandidate,
      addPlacement, updatePlacement,
      addActivity, updateActivity, deleteActivity,
    }}>
      {children}
    </CRMContext.Provider>
  );
}

export function useCRM() {
  const ctx = useContext(CRMContext);
  if (!ctx) throw new Error('useCRM must be used within CRMProvider');
  return ctx;
}
